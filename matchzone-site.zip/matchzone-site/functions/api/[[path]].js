// Cloudflare Pages Function: a small proxy in front of API-Football.
// The API key lives in the environment variable API_FOOTBALL_KEY and never reaches the browser.

const UPSTREAM = "https://v3.football.api-sports.io";

// Only these endpoints and parameters are forwarded. ttl is the cache time in seconds.
const ALLOWED = {
  "fixtures": { params: { date: /^\d{4}-\d{2}-\d{2}$/, live: /^all$/, timezone: /^[A-Za-z0-9_\/+-]{1,40}$/ }, ttl: 60 },
  "fixtures/lineups": { params: { fixture: /^\d{1,12}$/ }, ttl: 300 },
  "fixtures/events": { params: { fixture: /^\d{1,12}$/ }, ttl: 30 },
};

function json(body, status, ttl) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": ttl ? "public, max-age=" + ttl : "no-store",
    },
  });
}

function hasErrors(errors) {
  if (!errors) return false;
  return Array.isArray(errors) ? errors.length > 0 : Object.keys(errors).length > 0;
}

export async function onRequestGet(context) {
  const { request, env, params } = context;

  if (!env.API_FOOTBALL_KEY) return json({ error: "API key is not configured" }, 500);

  const path = Array.isArray(params.path) ? params.path.join("/") : String(params.path || "");
  const rule = ALLOWED[path];
  if (!rule) return json({ error: "not found" }, 404);

  const incoming = new URL(request.url).searchParams;
  const clean = new URLSearchParams();
  for (const [name, pattern] of Object.entries(rule.params)) {
    const value = incoming.get(name);
    if (value === null) continue;
    if (!pattern.test(value)) return json({ error: "invalid parameter: " + name }, 400);
    clean.set(name, value);
  }
  if ([...clean.keys()].length === 0) return json({ error: "missing parameters" }, 400);
  clean.sort();

  const cache = caches.default;
  const cacheKey = new Request(new URL("/__cache/" + path + "?" + clean.toString(), request.url).toString());
  const hit = await cache.match(cacheKey);
  if (hit) return hit;

  let upstream;
  try {
    upstream = await fetch(UPSTREAM + "/" + path + "?" + clean.toString(), {
      headers: { "x-apisports-key": env.API_FOOTBALL_KEY },
    });
  } catch (e) {
    return json({ error: "upstream unreachable" }, 502);
  }
  if (!upstream.ok) return json({ error: "upstream error" }, 502);

  let data;
  try { data = await upstream.json(); } catch (e) { return json({ error: "bad upstream response" }, 502); }
  // API-Football answers 200 with an "errors" field for things like an exhausted daily quota.
  if (hasErrors(data.errors)) return json({ error: "upstream refused the request" }, 502);

  const response = json({ response: data.response || [], results: data.results || 0 }, 200, rule.ttl);
  context.waitUntil(cache.put(cacheKey, response.clone()));
  return response;
}
