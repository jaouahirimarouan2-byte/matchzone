(function () {
  "use strict";

  var TZ = "";
  try { TZ = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) {}

  var LIVE = { "1H": 1, "HT": 1, "2H": 1, "ET": 1, "BT": 1, "P": 1, "LIVE": 1, "INT": 1 };
  var DONE = { "FT": 1, "AET": 1, "PEN": 1 };
  var UP = { "NS": 1, "TBD": 1 };
  var OTHER_LABEL = { PST: "مؤجلة", CANC: "ملغاة", SUSP: "موقوفة", ABD: "متوقفة", AWD: "فوز إداري", WO: "انسحاب" };
  var EV_LABEL = { goal: "هدف", yellow: "بطاقة صفراء", red: "بطاقة حمراء", sub: "تبديل", note: "مجريات" };
  var PAGE = 40;
  var REFRESH_MS = 60000;

  var state = { day: 0, liveOnly: false, q: "", limit: PAGE, matches: [], loading: true, error: false, sel: null, tab: "events", det: null, updated: null };
  var el = {
    sports: document.getElementById("sports"), days: document.getElementById("days"),
    list: document.getElementById("list"), detail: document.getElementById("detail"),
    liveText: document.getElementById("liveCountText"), q: document.getElementById("q"), updated: document.getElementById("updated")
  };
  var listToken = 0, detToken = 0;

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function hhmm(d) { return pad(d.getHours()) + ":" + pad(d.getMinutes()); }
  function hue(s) { var h = 0; s = String(s); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
  function offsetDate(o) { var d = new Date(); d.setDate(d.getDate() + o); return d; }
  function dateStr(o) { var d = offsetDate(o); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function isDesktop() { return window.matchMedia("(min-width: 900px)").matches; }

  function api(path, params) {
    var qs = new URLSearchParams(params).toString();
    return fetch("/api/" + path + "?" + qs).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok || (j && j.error)) throw new Error((j && j.error) || "request failed");
        return j;
      });
    });
  }

  function mapFixture(f) {
    var s = f.fixture.status.short;
    var st = LIVE[s] ? "live" : DONE[s] ? "finished" : UP[s] ? "upcoming" : "other";
    var pen = f.score && f.score.penalty && f.score.penalty.home != null ? f.score.penalty : null;
    return {
      id: f.fixture.id, league: f.league.name, country: f.league.country || "",
      time: new Date(f.fixture.date), status: st, code: s,
      elapsed: f.fixture.status.elapsed, extra: f.fixture.status.extra,
      label: OTHER_LABEL[s] || f.fixture.status.long || s,
      home: { id: f.teams.home.id, name: f.teams.home.name, logo: f.teams.home.logo },
      away: { id: f.teams.away.id, name: f.teams.away.name, logo: f.teams.away.logo },
      hs: f.goals.home, as: f.goals.away, pen: pen
    };
  }

  function minuteText(m) {
    if (m.code === "HT") return "استراحة";
    if (m.elapsed == null) return "";
    return m.elapsed + (m.extra ? "+" + m.extra : "") + "'";
  }

  /* ---------- Filters ---------- */
  function dayLabel(o) {
    if (o === 0) return "اليوم";
    if (o === -1) return "أمس";
    if (o === 1) return "غدًا";
    return offsetDate(o).toLocaleDateString("ar-MA-u-nu-latn", { weekday: "long" });
  }
  function dayDate(o) { return offsetDate(o).toLocaleDateString("ar-MA-u-nu-latn", { day: "numeric", month: "short" }); }

  function renderFilters() {
    el.sports.innerHTML =
      '<button class="chip" data-live="0" aria-pressed="' + !state.liveOnly + '">كل المباريات</button>' +
      '<button class="chip live-chip" data-live="1" aria-pressed="' + state.liveOnly + '">مباشر الآن</button>';
    var d = "";
    for (var o = -1; o <= 3; o++) {
      d += '<button class="day" role="tab" data-day="' + o + '" aria-selected="' + (!state.liveOnly && state.day === o) + '"><span>' + dayLabel(o) + "</span><small>" + dayDate(o) + "</small></button>";
    }
    el.days.innerHTML = d;
  }

  /* ---------- List ---------- */
  function badge(t) {
    var img = t.logo ? '<img src="' + esc(t.logo) + '" alt="" loading="lazy">' : "";
    return '<i class="badge" style="--h:' + hue(t.name) + '">' + esc(t.name.charAt(0)) + img + "</i>";
  }
  function teamRow(m, side) {
    var t = side === "h" ? m.home : m.away;
    var sc = side === "h" ? m.hs : m.as, other = side === "h" ? m.as : m.hs;
    var cls = "team";
    if (m.status === "finished" && sc != null && other != null && sc !== other) cls += sc > other ? " win" : " lose";
    var shown = sc == null ? "–" : sc;
    return '<span class="' + cls + '">' + badge(t) + '<span class="tn">' + esc(t.name) + '</span><b class="sc">' + shown + "</b></span>";
  }
  function stateCol(m) {
    if (m.status === "live") return '<span class="pill-live"><span class="dot"></span>مباشر</span><span class="live-min">' + esc(minuteText(m)) + "</span>";
    if (m.status === "finished") return '<span class="big">انتهت</span><span>' + hhmm(m.time) + "</span>";
    if (m.status === "other") return '<span class="big" style="font-size:15px">' + esc(m.label) + "</span>";
    return '<span class="big num">' + hhmm(m.time) + "</span><span>لم تبدأ</span>";
  }

  function filtered() {
    var q = state.q.trim().toLowerCase();
    return state.matches.filter(function (m) {
      if (!q) return true;
      return (m.home.name + " " + m.away.name + " " + m.league + " " + m.country).toLowerCase().indexOf(q) !== -1;
    });
  }

  function renderList() {
    if (state.loading && !state.matches.length) { el.list.innerHTML = '<div class="loading">جارٍ تحميل المباريات…</div>'; return; }
    if (state.error && !state.matches.length) {
      el.list.innerHTML = '<div class="err">تعذّر تحميل المباريات الآن.<br><button data-retry="1">إعادة المحاولة</button></div>';
      return;
    }
    var items = filtered();
    if (!items.length) { el.list.innerHTML = '<div class="empty">لا توجد مباريات مطابقة.</div>'; return; }

    var groups = {}, keys = [];
    items.forEach(function (m) {
      var k = m.league + "|" + m.country;
      if (!groups[k]) { groups[k] = { name: m.league, country: m.country, rows: [], live: false }; keys.push(k); }
      groups[k].rows.push(m);
      if (m.status === "live") groups[k].live = true;
    });
    keys.sort(function (a, b) {
      var A = groups[a], B = groups[b];
      if (A.live !== B.live) return A.live ? -1 : 1;
      return A.name.localeCompare(B.name);
    });

    var shown = 0, html = "";
    for (var i = 0; i < keys.length && shown < state.limit; i++) {
      var g = groups[keys[i]];
      g.rows.sort(function (a, b) { return a.time - b.time; });
      var rows = g.rows.slice(0, state.limit - shown);
      shown += rows.length;
      html += '<div class="league"><h2>' + esc(g.name) + (g.country ? " · " + esc(g.country) : "") + '</h2><div class="rows">' + rows.map(function (m) {
        return '<button class="match" data-id="' + m.id + '" aria-current="' + (state.sel && state.sel.id === m.id) + '">' +
          '<span class="state">' + stateCol(m) + "</span>" +
          '<span class="teams">' + teamRow(m, "h") + teamRow(m, "a") + "</span></button>";
      }).join("") + "</div></div>";
    }
    if (shown < items.length) html += '<button class="more" data-more="1">عرض المزيد (' + (items.length - shown) + ")</button>";
    el.list.innerHTML = html;
  }

  function renderLiveCount(n) {
    el.liveText.textContent = n ? n + " مباراة مباشرة الآن" : "لا توجد مباريات مباشرة الآن";
  }
  function renderUpdated() {
    el.updated.textContent = state.updated ? "آخر تحديث " + hhmm(state.updated) : "";
  }

  /* ---------- Data loading ---------- */
  function loadList(silent) {
    var token = ++listToken;
    if (!silent) { state.loading = true; state.error = false; state.matches = []; state.limit = PAGE; renderList(); }
    var params = state.liveOnly ? { live: "all" } : { date: dateStr(state.day) };
    if (TZ) params.timezone = TZ;
    return api("fixtures", params).then(function (j) {
      if (token !== listToken) return;
      state.matches = (j.response || []).map(mapFixture);
      state.loading = false; state.error = false; state.updated = new Date();
      if (state.liveOnly) renderLiveCount(state.matches.length);
      renderList(); renderUpdated();
      if (state.sel) {
        var cur = state.matches.filter(function (m) { return m.id === state.sel.id; })[0];
        if (cur) { state.sel = cur; renderDetail(); }
      }
    }).catch(function () {
      if (token !== listToken) return;
      state.loading = false;
      if (!silent || !state.matches.length) state.error = true;
      renderList();
    });
  }

  function loadLiveCount() {
    var params = { live: "all" };
    if (TZ) params.timezone = TZ;
    api("fixtures", params).then(function (j) { renderLiveCount((j.response || []).length); }).catch(function () {
      el.liveText.textContent = "المباريات المباشرة";
    });
  }

  function mapEvents(arr, homeId) {
    return (arr || []).map(function (e) {
      var type = "note", text = e.player && e.player.name ? e.player.name : "";
      var d = (e.detail || "").toLowerCase();
      if (e.type === "Goal") { type = d.indexOf("missed") !== -1 ? "note" : "goal"; if (d.indexOf("missed") !== -1) text = "ركلة جزاء ضائعة: " + text; if (d.indexOf("own") !== -1) text += " (عكسي)"; }
      else if (e.type === "Card") type = d.indexOf("red") !== -1 ? "red" : "yellow";
      else if (e.type && e.type.toLowerCase() === "subst") { type = "sub"; text = (e.assist && e.assist.name ? e.assist.name + " ⇄ " : "") + text; }
      else if (e.type === "Var") { type = "note"; text = "مراجعة الفيديو (" + (e.detail || "") + ")"; }
      var el_ = e.time && e.time.elapsed != null ? e.time.elapsed : 0, ex = e.time && e.time.extra ? e.time.extra : 0;
      return { sort: el_ * 100 + ex, min: el_ + (ex ? "+" + ex : "") + "'", type: type, text: text, home: e.team && e.team.id === homeId, team: e.team ? e.team.name : "" };
    }).sort(function (a, b) { return b.sort - a.sort; });
  }

  function loadDetail(silent) {
    var m = state.sel; if (!m) return;
    var token = ++detToken;
    if (!silent) { state.det = { loading: true }; renderDetail(); }
    var ev = api("fixtures/events", { fixture: m.id }).then(function (j) { return j.response || []; }).catch(function () { return null; });
    var lu = api("fixtures/lineups", { fixture: m.id }).then(function (j) { return j.response || []; }).catch(function () { return null; });
    Promise.all([ev, lu]).then(function (r) {
      if (token !== detToken) return;
      state.det = { events: r[0] ? mapEvents(r[0], m.home.id) : null, lineups: r[1], failed: !r[0] && !r[1] };
      renderDetail();
    });
  }

  /* ---------- Detail ---------- */
  function pitchSvg() {
    return '<svg viewBox="0 0 300 400" preserveAspectRatio="none" aria-hidden="true" fill="none" stroke="rgba(255,255,255,.55)" stroke-width="1.6">' +
      '<rect x="8" y="8" width="284" height="384"/><line x1="8" y1="200" x2="292" y2="200"/><circle cx="150" cy="200" r="34"/>' +
      '<rect x="80" y="8" width="140" height="62"/><rect x="80" y="330" width="140" height="62"/>' +
      '<rect x="116" y="8" width="68" height="24"/><rect x="116" y="368" width="68" height="24"/></svg>';
  }

  function groupRows(xi) {
    var hasGrid = xi.every(function (p) { return p.player && /^\d+:\d+$/.test(p.player.grid || ""); });
    var rows = {};
    if (hasGrid) {
      xi.forEach(function (p) { var g = p.player.grid.split(":"); (rows[g[0]] = rows[g[0]] || []).push({ c: +g[1], p: p.player }); });
    } else {
      var order = { G: 1, D: 2, M: 3, F: 4 };
      xi.forEach(function (p) { var r = order[p.player.pos] || 3; (rows[r] = rows[r] || []).push({ c: rows[r] ? rows[r].length : 0, p: p.player }); });
    }
    return Object.keys(rows).map(Number).sort(function (a, b) { return a - b; }).map(function (k) {
      return rows[k].sort(function (a, b) { return a.c - b.c; }).map(function (x) { return x.p; });
    });
  }

  function playersHtml(lineup, home) {
    var rows = groupRows(lineup.startXI || []), n = rows.length, out = "";
    rows.forEach(function (row, i) {
      var yH = 91 - i * (35 / (n > 1 ? n - 1 : 1));
      var y = home ? yH : 100 - yH;
      row.forEach(function (p, j) {
        var x = ((j + 1) / (row.length + 1)) * 100;
        out += '<div class="pl ' + (home ? "h" : "a") + '" style="left:' + x + "%;top:" + y + '%"><b>' + esc(p.number == null ? "" : p.number) + "</b><span>" + esc(p.name) + "</span></div>";
      });
    });
    return out;
  }

  function lineupHtml(m, det) {
    var L = det.lineups || [];
    var h = L.filter(function (x) { return x.team && x.team.id === m.home.id; })[0];
    var a = L.filter(function (x) { return x.team && x.team.id === m.away.id; })[0];
    if (!h || !a || !(h.startXI || []).length || !(a.startXI || []).length) {
      return '<div class="no-lineup">التشكيلة غير متاحة بعد، وتظهر قبل المباراة بقليل.</div>';
    }
    return '<div class="pitch-head"><span>' + esc(m.away.name) + ' <span class="fm">' + esc(a.formation || "") + "</span></span></div>" +
      '<div class="pitch">' + pitchSvg() + playersHtml(a, false) + playersHtml(h, true) + "</div>" +
      '<div class="pitch-head" style="margin:6px auto 0;max-width:380px"><span>' + esc(m.home.name) + ' <span class="fm">' + esc(h.formation || "") + "</span></span></div>";
  }

  function eventsHtml(det) {
    if (!det.events || !det.events.length) return '<div class="no-lineup">لا توجد أحداث حتى الآن.</div>';
    return '<ul class="events">' + det.events.map(function (e) {
      return '<li class="ev"><span class="m">' + esc(e.min) + '</span><span><span class="tag"><i class="' + e.type + '"></i>' + EV_LABEL[e.type] + '</span><br><span class="who">' + esc(e.text) + (e.team ? " · " + esc(e.team) : "") + "</span></span></li>";
    }).join("") + "</ul>";
  }

  function streamHtml() {
    return '<div class="stream"><div><strong>مساحة البث المباشر</strong><p>يظهر هنا مشغّل بث رسمي بعد ربط مزوّد مرخّص بحقوق هذه البطولة.</p></div></div>' +
      '<p class="stream-note">لا تُضف روابط بث غير مرخّصة، فقد يؤدي ذلك إلى حذف الموقع من الاستضافة ومحركات البحث.</p>';
  }

  function renderDetail() {
    var m = state.sel;
    if (!m) { el.detail.innerHTML = '<div class="detail-empty">اختر مباراة لعرض الأحداث والتشكيلة.</div>'; el.detail.classList.remove("open"); return; }
    var det = state.det || { loading: true };
    var score = (m.hs == null || m.status === "upcoming") ? '<span class="sep">–</span>' : m.hs + '<span class="sep">:</span>' + m.as;
    var st = m.status === "live" ? '<span class="pill-live"><span class="dot"></span>مباشر</span> <span class="live-min">' + esc(minuteText(m)) + "</span>"
      : m.status === "finished" ? "انتهت المباراة" : m.status === "other" ? esc(m.label) : "تبدأ الساعة " + hhmm(m.time) + " بتوقيت جهازك";
    var sub = m.pen ? "ركلات الترجيح " + m.pen.home + " - " + m.pen.away : "";
    var tabs = [["events", "الأحداث"], ["lineup", "التشكيلة"], ["stream", "البث"]];
    var body = det.loading ? '<div class="loading">جارٍ التحميل…</div>' : det.failed ? '<div class="no-lineup">تعذّر تحميل التفاصيل الآن.</div>' :
      state.tab === "events" ? eventsHtml(det) : state.tab === "lineup" ? lineupHtml(m, det) : "";
    if (state.tab === "stream") body = streamHtml();

    el.detail.innerHTML =
      '<button class="close" data-close="1">رجوع للمباريات</button>' +
      '<div class="d-league">' + esc(m.league) + (m.country ? " · " + esc(m.country) : "") + "</div>" +
      '<div class="board"><div>' + badge(m.home) + '<div class="tn">' + esc(m.home.name) + "</div></div>" +
      '<div class="score">' + score + "</div><div>" + badge(m.away) + '<div class="tn">' + esc(m.away.name) + "</div></div></div>" +
      '<div class="d-state">' + st + "</div>" + (sub ? '<div class="d-league" style="margin-top:4px">' + esc(sub) + "</div>" : "") +
      '<div class="tabs" role="tablist" style="margin-top:14px">' + tabs.map(function (t) {
        return '<button class="tab" role="tab" data-tab="' + t[0] + '" aria-selected="' + (state.tab === t[0]) + '">' + t[1] + "</button>";
      }).join("") + "</div>" + body;
    if (!isDesktop()) el.detail.classList.add("open");
  }

  /* ---------- Events ---------- */
  document.addEventListener("error", function (e) {
    var t = e.target;
    if (t && t.tagName === "IMG" && t.parentNode && t.parentNode.classList.contains("badge")) t.parentNode.removeChild(t);
  }, true);

  document.addEventListener("click", function (e) {
    var t = e.target.closest("button");
    if (!t) return;
    var d = t.dataset;
    if (d.live !== undefined) { state.liveOnly = d.live === "1"; renderFilters(); loadList(); return; }
    if (d.day !== undefined) { state.day = parseInt(d.day, 10); state.liveOnly = false; renderFilters(); loadList(); return; }
    if (d.retry) { loadList(); return; }
    if (d.more) { state.limit += PAGE; renderList(); return; }
    if (d.id) {
      var m = state.matches.filter(function (x) { return String(x.id) === d.id; })[0];
      if (!m) return;
      state.sel = m; state.tab = "events"; state.det = null;
      renderList(); loadDetail(); return;
    }
    if (d.tab) { state.tab = d.tab; renderDetail(); return; }
    if (d.close) { el.detail.classList.remove("open"); return; }
  });

  var qTimer;
  el.q.addEventListener("input", function () {
    clearTimeout(qTimer);
    qTimer = setTimeout(function () { state.q = el.q.value; state.limit = PAGE; renderList(); }, 150);
  });

  /* ---------- Start ---------- */
  renderFilters(); renderList(); renderDetail(); loadList(); loadLiveCount();

  setInterval(function () {
    if (document.hidden) return;
    loadLiveCount();
    if (state.liveOnly || state.day === 0) loadList(true);
    if (state.sel && state.sel.status === "live") loadDetail(true);
  }, REFRESH_MS);
})();
